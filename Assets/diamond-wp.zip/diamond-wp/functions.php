<?php


	define( 'EWF_SETUP_PAGE'			, 'functions.php');				# page containing setup
	define( 'EWF_SETUP_THEME_DOMAIN'	, 'diamond-wp');				# translation domain
	define( 'EWF_SETUP_THNAME'			, 'bitpub');					# theme options short name
	define( 'EWF_SETUP_TITLE'			, 'Diamond Setup');				# wordpress menu title
	define( 'EWF_SETUP_THEME_NAME'		, 'Diamond Wordpress');			# wordpress menu title
	define( 'EWF_SETUP_THEME_VERSION'	, '1.0');						# wordpress menu title
	
	
	include_once ('framework/framework-setup.php');

?>