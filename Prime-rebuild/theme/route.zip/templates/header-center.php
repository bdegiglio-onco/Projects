<?php echo cs_site_logo(); ?><!-- /site-logo -->

<header id="masthead" role="banner">

    <div class="container">
      <div class="cs-inner">
        <?php echo cs_site_menu(); ?><!-- /site-nav -->
      </div>
    </div>

    <?php echo cs_mobile_icon(); ?><!-- /mobile-icon -->

  <div id="site-header-shadow"></div>
</header><!-- /header -->