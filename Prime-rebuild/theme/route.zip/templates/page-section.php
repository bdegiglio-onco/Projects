<?php
/**
 *
 * Template Name: Full-width, without container
 * @since 1.0.0
 * @version 1.0.0
 *
 */
while ( have_posts() ) : the_post();
  the_content();
endwhile;