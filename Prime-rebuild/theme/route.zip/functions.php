<?php
/**
 *
 * Codestar Framework
 *
 * @author Codestar
 * @license Commercial License
 * @link http://codestar.me
 * @copyright 2014 Codestar Themes
 * @package CSFramework
 * @version 1.0.0
 *
 */
require_once( get_template_directory() . '/cs-framework/init.php' );